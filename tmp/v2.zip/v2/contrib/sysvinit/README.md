
System-V init for e.g. http://devuan.org

Assumes an executable `/usr/local/bin/miniflux`.

Configure in `etc/default/miniflux`

