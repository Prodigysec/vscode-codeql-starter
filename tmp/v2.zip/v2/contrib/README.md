The contrib directory contains various useful things contributed by the community.

Community contributions are not officially supported by the maintainers.
There is no guarantee whatsoever that anything in this folder works.
