Grafana Dashboard for Miniflux
