This folder contains Miniflux API collection for [Bruno](https://www.usebruno.com).

Bruno is a lightweight alternative to Postman/Insomnia.

- https://www.usebruno.com
- https://github.com/usebruno/bruno