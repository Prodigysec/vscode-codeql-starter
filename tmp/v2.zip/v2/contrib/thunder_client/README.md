Miniflux API Collection for Thunder Client VS Code Extension
============================================================

Official website: https://www.thunderclient.com

This folder contains the API endpoints collection for Miniflux. You can import it locally to interact with the Miniflux API.
